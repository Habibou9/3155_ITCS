class AddressController < ApplicationController
  def index
  end
end
